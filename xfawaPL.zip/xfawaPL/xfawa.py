#!/usr/bin/env python3
import sys
import os
import subprocess
import tempfile
import re
import shutil

class XfawaEngine:
    def __init__(self):
        self.variables = {}
    
    def execute_file(self, filename):
        if not os.path.exists(filename):
            return f"File not found: {filename}"
        
        with open(filename, 'r', encoding='utf-8') as f:
            content = f.read()
        
        return self._parse_and_execute(content)
    
    def _parse_and_execute(self, content):
        results = []
        
        pattern = r'#(\w+)\s*\[\[(.*?)\]\]'
        matches = re.findall(pattern, content, re.DOTALL)
        
        if not matches:
            return content
        
        for lang, code in matches:
            lang = lang.lower().strip()
            code = code.strip()
            
            for var_name, var_value in self.variables.items():
                code = re.sub(r'\b' + re.escape(var_name) + r'\b', str(var_value), code)
            
            result = self._execute_language(lang, code)
            if result:
                results.append(result)
        
        return '\n'.join(results)
    
    def execute_line(self, line):
        line = line.strip()
        if not line or line.startswith('//'):
            return ""
        
        if ':=' in line:
            parts = line.split(':=', 1)
            if len(parts) == 2:
                key, value = parts[0].strip(), parts[1].strip()
                self.variables[key] = self._parse_value(value)
            return ""
        
        block_match = re.match(r'#(\w+)\s*\[\[(.*?)\]\]', line, re.DOTALL)
        if block_match:
            lang = block_match.group(1).lower()
            code = block_match.group(2).strip()
            
            for var_name, var_value in self.variables.items():
                code = re.sub(r'\b' + re.escape(var_name) + r'\b', str(var_value), code)
            
            return self._execute_language(lang, code)
        
        return line

    def _parse_value(self, value):
        if value.isdigit():
            return int(value)
        elif value.replace('.', '').isdigit():
            return float(value)
        elif value.lower() in ('true', 'false'):
            return value.lower() == 'true'
        elif (value.startswith('"') and value.endswith('"')) or \
             (value.startswith("'") and value.endswith("'")):
            return value[1:-1]
        else:
            return value

    def _execute_language(self, lang, code):
        try:
            if lang == 'python':
                return self._exec_python(code)
            elif lang in ['bash', 'shell', 'sh']:
                return self._exec_bash(code)
            elif lang == 'lua':
                return self._exec_lua(code)
            elif lang == 'c':
                return self._exec_c(code)
            elif lang in ['cpp', 'c++']:
                return self._exec_cpp(code)
            elif lang == 'go':
                return self._exec_go(code)
            elif lang == 'ruby':
                return self._exec_ruby(code)
            elif lang == 'php':
                return self._exec_php(code)
            elif lang == 'java':
                return self._exec_java(code)
            elif lang in ['js', 'javascript']:
                return self._exec_javascript(code)
            else:
                return f"Unsupported language: {lang}"
        except Exception as e:
            return f"{lang} Error: {e}"

    def _exec_python(self, code):
        try:
            from io import StringIO
            import contextlib
            
            output = StringIO()
            with contextlib.redirect_stdout(output):
                exec(code, {}, self.variables)
            return output.getvalue()
        except Exception as e:
            return f"Python Error: {e}"

    def _exec_bash(self, code):
        try:
            result = subprocess.run(['bash', '-c', code], capture_output=True, text=True, timeout=30)
            output = result.stdout
            if result.stderr:
                output += f"\nError: {result.stderr}"
            return output
        except subprocess.TimeoutExpired:
            return "Bash Timeout"
        except Exception as e:
            return f"Bash Error: {e}"

    def _exec_lua(self, code):
        try:
            result = subprocess.run(['lua', '-e', code], capture_output=True, text=True, timeout=30)
            output = result.stdout
            if result.stderr:
                output += f"\nError: {result.stderr}"
            return output
        except Exception as e:
            return f"Lua Error: {e}"

    def _exec_c(self, code):
        try:
            with tempfile.NamedTemporaryFile(mode='w', suffix='.c', delete=False) as f:
                f.write(code)
                c_file = f.name
            
            exe_file = c_file.replace('.c', '.out')
            compile_result = subprocess.run(['gcc', c_file, '-o', exe_file], capture_output=True, text=True, timeout=60)
            if compile_result.returncode != 0:
                return f"C Compile Error: {compile_result.stderr}"
            
            result = subprocess.run([exe_file], capture_output=True, text=True, timeout=30)
            
            os.unlink(c_file)
            if os.path.exists(exe_file):
                os.unlink(exe_file)
            
            output = result.stdout
            if result.stderr:
                output += f"\nError: {result.stderr}"
            return output
        except Exception as e:
            return f"C Error: {e}"

    def _exec_cpp(self, code):
        try:
            with tempfile.NamedTemporaryFile(mode='w', suffix='.cpp', delete=False) as f:
                f.write(code)
                cpp_file = f.name
            
            exe_file = cpp_file.replace('.cpp', '.out')
            compile_result = subprocess.run(['g++', cpp_file, '-o', exe_file], capture_output=True, text=True, timeout=60)
            if compile_result.returncode != 0:
                return f"C++ Compile Error: {compile_result.stderr}"
            
            result = subprocess.run([exe_file], capture_output=True, text=True, timeout=30)
            
            os.unlink(cpp_file)
            if os.path.exists(exe_file):
                os.unlink(exe_file)
            
            output = result.stdout
            if result.stderr:
                output += f"\nError: {result.stderr}"
            return output
        except Exception as e:
            return f"C++ Error: {e}"

    def _exec_go(self, code):
        try:
            with tempfile.NamedTemporaryFile(mode='w', suffix='.go', delete=False) as f:
                f.write(code)
                go_file = f.name
            
            result = subprocess.run(['go', 'run', go_file], capture_output=True, text=True, timeout=60)
            os.unlink(go_file)
            
            output = result.stdout
            if result.stderr:
                output += f"\nError: {result.stderr}"
            return output
        except Exception as e:
            return f"Go Error: {e}"

    def _exec_ruby(self, code):
        try:
            result = subprocess.run(['ruby', '-e', code], capture_output=True, text=True, timeout=30)
            output = result.stdout
            if result.stderr:
                output += f"\nError: {result.stderr}"
            return output
        except Exception as e:
            return f"Ruby Error: {e}"

    def _exec_php(self, code):
        try:
            result = subprocess.run(['php', '-r', code], capture_output=True, text=True, timeout=30)
            output = result.stdout
            if result.stderr:
                output += f"\nError: {result.stderr}"
            return output
        except Exception as e:
            return f"PHP Error: {e}"

    def _exec_java(self, code):
        try:
            with tempfile.NamedTemporaryFile(mode='w', suffix='.java', delete=False) as f:
                f.write(code)
                java_file = f.name
            
            class_dir = tempfile.mkdtemp()
            compile_result = subprocess.run(['javac', '-d', class_dir, java_file], capture_output=True, text=True, timeout=60)
            if compile_result.returncode != 0:
                return f"Java Compile Error: {compile_result.stderr}"
            
            class_name = "Main"
            class_match = re.search(r'class\s+(\w+)', code)
            if class_match:
                class_name = class_match.group(1)
            
            result = subprocess.run(['java', '-cp', class_dir, class_name], capture_output=True, text=True, timeout=30)
            
            os.unlink(java_file)
            shutil.rmtree(class_dir)
            
            output = result.stdout
            if result.stderr:
                output += f"\nError: {result.stderr}"
            return output
        except Exception as e:
            return f"Java Error: {e}"

    def _exec_javascript(self, code):
        try:
            result = subprocess.run(['node', '-e', code], capture_output=True, text=True, timeout=30)
            output = result.stdout
            if result.stderr:
                output += f"\nError: {result.stderr}"
            return output
        except Exception as e:
            return f"JavaScript Error: {e}"

def main():
    engine = XfawaEngine()
    
    if len(sys.argv) > 1:
        filename = sys.argv[1]
        result = engine.execute_file(filename)
        print(result)
    else:
        print("XfawaPL Multi-language Engine")
        print("Usage: python xfawa.py filename.xf")
        print("=" * 50)
        
        while True:
            try:
                command = input("xfawa> ").strip()
                if command == 'exit':
                    break
                result = engine.execute_line(command)
                if result:
                    print(result)
            except KeyboardInterrupt:
                print("\nExit")
                break

if __name__ == "__main__":
    main()
